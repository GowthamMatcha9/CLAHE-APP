# CLAHE Image Calculator — installable app package

This folder turns the widget into a **PWA** (Progressive Web App) — a real
installable app icon, works offline, no browser chrome. From here there
are two ways to get it on a phone:

## Option A — Install directly, no APK needed (easiest)
1. Upload this folder to any static host — e.g. GitHub Pages, Netlify, or
   Vercel (all free, drag-and-drop).
2. Open the hosted link on an Android phone in Chrome. You'll see an
   **"Install app"** button (or Chrome's menu → *Add to Home screen*).
3. It installs like a normal app: own icon, own window, works offline
   after first load. This is the same mechanism Twitter Lite, Starbucks,
   and Spotify's lite apps use.

## Option B — An actual .apk file to share
Google's own free tool wraps a hosted PWA into a real signed APK:
1. Do step 1 above first (the PWA must be hosted at a public URL).
2. Go to **pwabuilder.com**, paste your hosted URL.
3. Click **Package for Stores → Android**, download the generated `.apk`.
4. Share that `.apk` file directly — anyone can install it by opening it
   on their phone (they'll need to allow "install from unknown sources"
   the first time, since it isn't from the Play Store).

Building a signed APK from scratch needs the Android SDK/Gradle toolchain,
which isn't available in this environment — PWABuilder runs that step on
Google's infrastructure for free, so it's the practical path here.

## Files
- `index.html` — the app itself (identical CLAHE logic to the web version)
- `manifest.json` — name, icon, colours used when installed
- `sw.js` — service worker, caches the app for offline use
- `icons/` — app icons
